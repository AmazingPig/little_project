import random

matix = [[0 for i in range(4)] for i in range(4)] #生成一个都为0的4x4矩阵

def notzero(s):  #若不为0则显示
    return s if s != 0 else " "

def display(): #显示界面
    print(" ----- ----- ----- -----\n"
          "|  %s  |  %s  |  %s  |  %s  |\n"
          " ----- ----- ----- -----\n"
          "|  %s  |  %s  |  %s  |  %s  |\n"
          " ----- ----- ----- -----\n"
          "|  %s  |  %s  |  %s  |  %s  |\n"
          " ----- ----- ----- -----\n"
          "|  %s  |  %s  |  %s  |  %s  |\n"
          " ----- ----- ----- -----\n" %(notzero(matix[0][0]),notzero(matix[0][1]),notzero(matix[0][2]),notzero(matix[0][3]),\
                                         notzero(matix[1][0]),notzero(matix[1][1]),notzero(matix[1][2]),notzero(matix[1][3]),\
                                         notzero(matix[2][0]),notzero(matix[2][1]),notzero(matix[2][2]),notzero(matix[2][3]),\
                                         notzero(matix[3][0]),notzero(matix[3][1]),notzero(matix[3][2]),notzero(matix[3][3])))

def init():
    initNumFlag = 0
    while True:
        k = 2 if random.randrange(0,10) > 1 else 4 #随机生成一个2或者4，概率是9:1
        s = divmod(random.randrange(0,16),4)  #s作为矩阵下标
        if matix[s[0]][s[1]] == 0 :
            matix[s[0]][s[1]] = k
            initNumFlag += 1
            if initNumFlag == 2:
                break

init()
display()

def addRandomNum():
    k = 2 if random.randrange(0, 10) > 1 else 4
    s = divmod(random.randrange(0, 16), 4)
    if matix[s[0]][s[1]] == 0:
        matix[s[0]][s[1]] = k
    display()

def moveDown():
    global score
    change = False
    for i in range(4):
        for j in range(3, 0, -1):
            for k in range(j - 1, -1, -1):
                if matix[k][i] > 0:
                    if matix[j][i] == 0:
                        matix[j][i] = matix[k][i]
                        matix[k][i] = 0
                        change = True
                    elif matix[k][i] == matix[j][i]:
                        matix[j][i] *= 2
                        score += matix[j][i]
                        matix[k][i] = 0
                        change = True
    if change:
        addRandomNum()
    else:
        print("cannot move")

def moveUp():
    global score
    change = False
    for i in range(4):
        for j in range(3):
            for k in range(j+1,4):
                if matix[k][i] > 0 :
                    if matix[j][i] == 0 :
                        matix[j][i] = matix[k][i]
                        matix[k][i] = 0
                        change = True
                    elif matix[j][i] == matix[k][i]:
                        matix[j][i] *= 2
                        score += matix[j][i]
                        matix[k][i] = 0
                        change = True
    if change:
        addRandomNum()
    else:
        print("cannot move")

def moveRight():
    global score
    change = False
    for i in range(4):
        for j in range(3,0,-1):
            for k in range(j-1,-1,-1):
                if matix[i][k] > 0 :
                    if matix[i][j] == 0:
                        matix[i][j] = matix[i][k]
                        matix[i][k] = 0
                        change = True
                    elif matix[i][j] == matix[i][k] :
                        matix[i][j] *= 2
                        score += matix[i][j]
                        matix[i][k] = 0
                        change = True
    if change:
        addRandomNum()
    else:
        print("cannot move")

def moveLeft():
    global score
    change = False
    for i in range(4):
        for j in range(3):
            for k in range(j+1,4):
                if matix[i][k] > 0 :
                    if matix[i][j] == 0:
                        matix[i][j] = matix[i][k]
                        matix[i][k] = 0
                        change = True
                    elif matix[i][j] == matix[i][k]:
                        matix[i][j] *= 2
                        score += matix[i][j]
                        matix[i][k] = 0
                        change = True
    if change:
        addRandomNum()
    else:
        print("cannot move")

def gg():
    gg = True
    for i in range(4):
        for j in range(3):
            if matix[i][j] ==0 or matix[i][j] == matix[i][j+1] or matix[j][i] == matix[j+1][i]:
                gg = False

score = 0
def main():
    win_or_lose = True
    while win_or_lose:
        print("Your score is %s:" %score)
        d = input("左：a，上：w，下：s，右，退出：q")
        if d == "w":
            moveUp()
            if gg():
                print("GG")
                win_or_lose = False
        elif d == "a":
            moveLeft()
            if gg():
                print("GG")
                win_or_lose = False
        elif d == "s":
            moveDown()
            if gg():
                print("GG")
                win_or_lose = False
        elif d == "d":
            moveRight()
            if gg():
                print("GG")
                win_or_lose = False
        elif d == "q":
            break
        else:
            pass

main()
